export const environment = {
  production: false,
  apiUrl: 'http://my-api-url'
};
