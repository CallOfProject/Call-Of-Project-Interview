export class CodingInterviewDTO {
  public title: string
  public description: string
  public duration_minutes: number
  public question: string
  public point: number
  public interview_id: string
  public project_id: string
}
