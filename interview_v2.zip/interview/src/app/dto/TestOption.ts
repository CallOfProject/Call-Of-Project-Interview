export class TestOption {
  constructor(public optionText: string, public isCorrect: boolean) {

  }
}
