export class LoginRequestDTO {
  public username: string
  public password: string

  constructor() {
  }
}
